﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1.Realizar un programa que pida cargar una fecha cualquiera, luego verificar si dicha fecha corresponde a Navidad.
            int dia, mes, año;
            string linea;
            Console.WriteLine("Ingrese un N° de un dia: ");
            linea = Console.ReadLine();
            dia = int.Parse(linea);

            Console.WriteLine("Ingrese un mes (Con un numero): ");
            linea = Console.ReadLine();
            mes = int.Parse(linea);

            Console.WriteLine("Ingrese un año: ");
            linea = Console.ReadLine();
            año = int.Parse(linea);

            if (dia == 25 && mes == 12 && año > 0)
            {
            Console.WriteLine("La fecha ingresada corresponde a Navidad");
            }
        }
    }
}
