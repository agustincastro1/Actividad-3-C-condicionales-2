﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*5. Escribir un programa que pida ingresar la coordenada de un punto en el plano, es decir dos valores enteros x e y (distintos a cero).
            Posteriormente imprimir en pantalla en que cuadrante se ubica dicho punto. (1º Cuadrante si x > 0 e y > 0 , 2º Cuadrante: x < 0 Y y > 0). */

            int x , y;
            string linea;

            Console.WriteLine("Ingrese la coordenada x (que no sea 0): ");
            linea = Console.ReadLine();
            x = int.Parse(linea);

            Console.WriteLine("Ingrese la coordenada y (que no sea 0): ");
            linea = Console.ReadLine();
            y = int.Parse(linea);

            if (x != 0 && y != 0)
            {
                if (x > 0 && y > 0)
                {
                    Console.Write("Está en el primer cuadrante");
                }
                if (x < 0 && y > 0)
                {
                    Console.Write("Está en el segundo cuadrante");
                }
            }
            Console.ReadKey();
        }
    }
}
